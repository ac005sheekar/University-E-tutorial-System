<h2>Reconnaissance Survey</h2><br><br><br>

It is the preliminary survey. It is used at commencement of any project work through suggesting possible alternative paths and routes. It needs to be done with greater efficiency and cost accuracy for identifying these alternative paths and routes.<br><br><br>

It is the process of identifying variable possible routes and evaluating possibility of these routes in a highway between the specific points. This is done especially for new routes between the rural areas, for which the aerial photographs are primarily used.<br><br><br>

It has four phase study processes as follows, 1) Research, 2) Draft report outline, 3) Draft sensitivity map and 4) Final report.<br><br><br>

Purpose of reconnaissance survey is discussed below.<br><br><br>

• The main purpose is for taking survey in a particular area about its weather conditions, map and terrain etc.,<br><br><br>

• It is used for assessing the flexibility of alternative corridor paths or routes for the highway between specific points and it can take into account the subsequent points as below.<br><br><br>

1) Topography, geology and traffic volume, 2) Environmental use and 3) Social and economic land use (construction unit cost, agricultural trends and commercial activities in industries)<br><br><br>

• It is used to estimate quantity of earthwork.<br><br><br>

• It is used to evaluate flood records, metrological statistics, topography and other existing services or communications.<br><br><br>

Significance of reconnaissance survey are as given below.<br><br><br>

• The results of reconnaissance survey is used to develop the plan, which is helpful to identify or protect the cultural resources.<br><br><br>

• It has to identify any archaeological sites nearby the alignment of routes.<br><br><br>

• To explore the site conditions with infrastructure availability.<br><br><br>

