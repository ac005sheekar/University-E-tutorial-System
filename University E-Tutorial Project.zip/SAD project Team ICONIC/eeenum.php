<?php
 include 'header.php';
 ?>
<br>
<br><br>


<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
header
{
    background-color:#6666ff ;
	border-radius:0px;
}

a{
	color: white;

}

.saidur{
	color: white;

}
body{
	background-image: url("back5.jpg");
}

.navbar {
    overflow: hidden;
	border-radius:0px;
    background-color: #ff4d88 ;
    font-family: Arial;
}

.navbar a {
    float: left;
    font-size: 15px;
    color: white;
    text-align: center;
    padding: 10px 14px;
    text-decoration: none;
}

.dropdown {
    float: left;
    overflow: hidden;
	
}

.dropdown .dropbtn {
    font-size: 13px;    
    border: none;
    outline: none;
    color:white;
    padding: 14px 18px;
    background-color: #ff4d88 ;
	width: 100%;
}

.navbar a:hover, .dropdown:hover .dropbtn {
    background-color: OrangeRed  ;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: LightCoral ;
    min-width: 150px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {
    background-color: #08f708;
}

.dropdown:hover .dropdown-content {
    display: block;
}
</style>
</head>
<body>
<header>
<body style="text-align:center;color:White;"; </body>
 
  
<div class="navbar">
  
  <div class="dropdown">
    <button class="dropbtn"><b>Computer Science</b>
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      
	  <a href="cseprog.php">Structured Programming language </a>
	  <a href="cseos.php">Operating Systems</a>
	  <a href="csegra.php">Computer Graphics</a>
	  <a href="csedata.php">Data Structures and Algorithms</a>
	  <a href="csetoc.php">Theory of Computations</a>
	  <a href="csecomp.php">Compiler Design</a>
	  <a href="csemp.php">Micro processors</a>
	  <a href="csesoft.php">Software Engineering</a>
	  
    </div>
  </div> 
  <div class="dropdown">
    <button class="dropbtn"><b>Electrical Engineering</b>
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="eeeca1.php">Circuit Analysis 1</a>
	  <a href="eeeca2.php">Circuit Analysis 2</a>
	  <a href="eeeec.php">Energy Conversion</a>
	  <a href="eeeelec.php">Electromagnetics</a>
	  <a href="eeeconsig.php">Continuous Signals</a>
	  <a href="eeenum.php">Numerical Techniques</a>
	  <a href="eeedigsig.php">Digital Signals</a>
	  <a href="eeedigelec.php">Digital Electronics</a>
	  <a href="eeecomm.php">Communication Systems</a>
	  <a href="eeeconsys.php">Control Systems</a>
	  <a href="eeemp.php">Micro processors and Embedded Systems</a>
	  
	  
    </div>
  </div> 
  
  
  <div class="dropdown">
    <button class="dropbtn"><b>Civil Engineering</b>
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="ceana.php">Analytic Mechanics</a>
	  <a href="cesur.php">Surveying</a>
	  <a href="cegeo.php">Geology and Geomorphology</a>
	  <a href="cefluid.php">Fluid Mechanics</a>
	  <a href="cestuct.php">Structural Analysis</a>
	  <a href="ceenviron.php">Environmental Engineering</a>
	  <a href="cesoil.php">Soil Mechanics</a>
	  <a href="cetraffic.php">Transportation Engineering: Traffic Engineering</a>
	  <a href="cepave.php">Transportation Engineering: Pavement Design</a>
	  <a href="cerail.php">Transportation Engineering: Railway Engineering</a>
	  
	  
	  
    </div>
  </div>

  
  
  
  
  
     
	
  
</header>

<h2>Welcome to Electrical Engineering</h2><br><br>
<h3>Numerical Techniques</h3><br><br>

<?php
 include 'slideeee.php';
 ?>
 
 
 
<body class="saidur">

	In numerical analysis, a numerical method is a mathematical tool designed to solve numerical problems. The implementation of a numerical method with an appropriate convergence check in a programming language is called a numerical algorithm.<br><br><br><br>
	Mathematical definition<br><br><br>
Let {\displaystyle F(x,y)=0} F(x,y)=0 be a well-posed problem, i.e. {\displaystyle F:X\times Y\rightarrow \mathbb {R} } {\displaystyle F:X\times Y\rightarrow \mathbb {R} } is a real or complex functional relationship, defined on the cross-product of some input data set {\displaystyle X} X and an output set {\displaystyle Y} Y, such that exists a locally lipschitz function {\displaystyle g:X\rightarrow Y} {\displaystyle g:X\rightarrow Y} called resolvent, which has the property that for every root {\displaystyle (x,y)} (x,y) of {\displaystyle F} F, {\displaystyle y=g(x)} y=g(x). We define numerical method for the approximation of {\displaystyle F(x,y)=0} F(x,y)=0, the sequence of problems<br><br><br>

{\displaystyle \left\{M_{n}\right\}_{n\in \mathbb {N} }=\left\{F_{n}(x_{n},y_{n})=0\right\}_{n\in \mathbb {N} },} {\displaystyle \left\{M_{n}\right\}_{n\in \mathbb {N} }=\left\{F_{n}(x_{n},y_{n})=0\right\}_{n\in \mathbb {N} },}<br><br><br><br>
with {\displaystyle F_{n}:X_{n}\times Y_{n}\rightarrow \mathbb {R} } {\displaystyle F_{n}:X_{n}\times Y_{n}\rightarrow \mathbb {R} }, {\displaystyle x_{n}\in X_{n}} {\displaystyle x_{n}\in X_{n}} and {\displaystyle y_{n}\in Y_{n}} {\displaystyle y_{n}\in Y_{n}} for every {\displaystyle n\in \mathbb {N} } n\in \mathbb {N} . The problems of which the method consists need not be well-posed. If they are, the method is said to be stable or well-posed.<br><br><br>

Consistency<br><br><br>
Necessary conditions for a numerical method to effectively approximate {\displaystyle F(x,y)=0} F(x,y)=0 are that {\displaystyle x_{n}\rightarrow x} x_{n}\rightarrow x and that {\displaystyle F_{n}} F_{n} behaves like {\displaystyle F} F when {\displaystyle n\rightarrow \infty } n\rightarrow \infty . So, a numerical method is called consistent if and only if the sequence of functions {\displaystyle \left\{F_{n}\right\}_{n\in \mathbb {N} }} {\displaystyle \left\{F_{n}\right\}_{n\in \mathbb {N} }} pointwise converges to {\displaystyle F} F on the set {\displaystyle S} S of its solutions:<br><br><br>

{\displaystyle \lim F_{n}(x,y)=F(x,y)=0,\quad \quad \forall (x,y)\in S.} {\displaystyle \lim F_{n}(x,y)=F(x,y)=0,\quad \quad \forall (x,y)\in S.}<br><br><br>
When {\displaystyle F_{n}=F,\forall n\in \mathbb {N} } {\displaystyle F_{n}=F,\forall n\in \mathbb {N} } on {\displaystyle S} S the method is said to be strictly consistent.<br><br><br>

Convergence<br><br><br>
Denote by {\displaystyle \ell _{n}} \ell_n a sequence of admissible perturbations of {\displaystyle x\in X} x\in X for some numerical method {\displaystyle M} M (i.e. {\displaystyle x+\ell _{n}\in X_{n}\forall n\in \mathbb {N} } {\displaystyle x+\ell _{n}\in X_{n}\forall n\in \mathbb {N} }) and with {\displaystyle y_{n}(x+\ell _{n})\in Y_{n}} {\displaystyle y_{n}(x+\ell _{n})\in Y_{n}} the value such that {\displaystyle F_{n}(x+\ell _{n},y_{n}(x+\ell _{n}))=0} {\displaystyle F_{n}(x+\ell _{n},y_{n}(x+\ell _{n}))=0}. A condition which the method has to satisfy to be a meaningful tool for solving the problem {\displaystyle F(x,y)=0} F(x,y)=0 is convergence:<br><br><br>

{\displaystyle {\begin{aligned}&\forall \varepsilon >0,\exists n_{0}(\varepsilon )>0,\exists \delta _{\varepsilon ,n_{0}}{\text{ such that}}\\&\forall n>n_{0},\forall \ell _{n}:\|\ell _{n}\|<\delta _{\varepsilon ,n_{0}}\Rightarrow \|y_{n}(x+\ell _{n})-y\|\leq \varepsilon .\end{aligned}}} {\displaystyle {\begin{aligned}&\forall \varepsilon >0,\exists n_{0}(\varepsilon )>0,\exists \delta _{\varepsilon ,n_{0}}{\text{ such that}}\\&\forall n>n_{0},\forall \ell _{n}:\|\ell _{n}\|<\delta _{\varepsilon ,n_{0}}\Rightarrow \|y_{n}(x+\ell _{n})-y\|\leq \varepsilon .\end{aligned}}}<br><br><br><br><br>
One can easily prove that the point-wise convergence of {\displaystyle \{y_{n}\}_{n\in \mathbb {N} }} {\displaystyle \{y_{n}\}_{n\in \mathbb {N} }} to {\displaystyle y} y implies the convergence of the associated method.<br><br><br>
	
	
	

</body>
 <br><br><br>
 
 <div id="google_translate_element"></div>

<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

<br><br><br><br>

<?php
 include 'footer.php';
 ?>
