-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 06, 2018 at 08:13 AM
-- Server version: 5.5.32
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `project`
--
CREATE DATABASE IF NOT EXISTS `project` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `project`;

-- --------------------------------------------------------

--
-- Table structure for table `admin1`
--

CREATE TABLE IF NOT EXISTS `admin1` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin1`
--

INSERT INTO `admin1` (`id`, `username`, `password`) VALUES
(1, 'nishat', 'rajshahi');

-- --------------------------------------------------------

--
-- Table structure for table `feed_tea`
--

CREATE TABLE IF NOT EXISTS `feed_tea` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `feed_tea` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `feed_tea`
--

INSERT INTO `feed_tea` (`id`, `feed_tea`) VALUES
(1, 'Need some improvement'),
(2, 'Quite satisfactory');

-- --------------------------------------------------------

--
-- Table structure for table `feed_tuto`
--

CREATE TABLE IF NOT EXISTS `feed_tuto` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `feed_tuto` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `feed_tuto`
--

INSERT INTO `feed_tuto` (`id`, `feed_tuto`) VALUES
(1, 'It must be more informative'),
(2, 'Tutorial was very much Helpful. Thanks.');

-- --------------------------------------------------------

--
-- Table structure for table `stu1`
--

CREATE TABLE IF NOT EXISTS `stu1` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `stu1`
--

INSERT INTO `stu1` (`id`, `username`, `password`) VALUES
(1, 'sheekar', 'mallory'),
(3, ' barak obama', 'trump');

-- --------------------------------------------------------

--
-- Table structure for table `teacher1`
--

CREATE TABLE IF NOT EXISTS `teacher1` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `teacher1`
--

INSERT INTO `teacher1` (`id`, `username`, `password`) VALUES
(1, 'meem', 'dhaka'),
(2, ' innika', 'kustia');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
