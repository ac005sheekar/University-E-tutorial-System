<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.footer {
   
   left: 0;
   bottom: 0;
   width: 100%;
   border-radius:30px;
   background-color: #6666ff  ;
   color: white;
   text-align: center;
}
</style>
</head>
<body>
<div class="footer">
  <p><b>Copyright :<br>Team Iconic<br>System Analysis and Design<br>Section: Excellent     </b></p>
  
</div>

</body>
</html>
