<?php
$con=mysqli_connect('localhost','root','', 'project') ;//login Database name // be careful
?>